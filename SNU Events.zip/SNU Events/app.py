from re import A
from flask import Flask, render_template, json, request, redirect, session, \
    flash, url_for
from flaskext.mysql import MySQL
from pymysql import NULL
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import logging

mysql = MySQL()
app = Flask(__name__)
# app.config.from_envvar('universityapp_settings')
app.secret_key = 'secret'

# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''
app.config['MYSQL_DATABASE_DB'] = 'eventwebsite'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)

@app.route('/')
def main():
    if session.get('user'):
        return redirect('/userhome')
    return render_template('index.html')

#use the def name when calling the route through code

@app.route('/signup')
def signup():
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.callproc('sp_get_universities', )
    universities = cursor.fetchall()

    university_array = []
    for university in university_array:
        university_item = [
            university[0], university[1], university[2]
        ]
        university_array.append(university_item)

    cursor.close()
    conn.close()
    return render_template('signup.html', university_list = universities)

@app.route('/signin')
def signin():
    if session.get('user'):
        return render_template('userhome.html')
    return render_template('signin.html')

@app.route('/eventapproval_list')
def eventapproval_list():
    try:
        if session.get('user_role') == 'super_admin':

            # _viewby = session.get('event-view-type')
            
            # _sortby = session.get('event-sort-type')
            # _userUniversity = session.get('user-university')
        
            conn = mysql.connect()
            cursor = conn.cursor()
            #cursor.callproc('sp_get_events_by_type_sort', (_viewby, _sortby, _userUniversity))
            cursor.execute("select * from events where event_approval=0;")
            conn.commit()
            events = cursor.fetchall()

            events_list = []
            for event in events:
                event_item = [
                    event[1], event[3], event[0]
                ]
                events_list.append(event_item)

            if(len(events)==0):
                flash("There are no pending events requests", "alert-success")

            cursor.close()
            conn.close()

            return render_template('eventapproval_list.html', events=events_list)
        else:
            return render_template('error.html', error="You must be logged in to access this page.")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})

@app.route('/appevent_deets/<eventid>')
def appevent_deets(eventid):
    try:    
        if session.get('user_role')=='super_admin':
            _event_id = int(eventid)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.callproc('sp_get_event', (eventid, ))
            eventdata = cursor.fetchall()

            if len(eventdata) == 0:
                conn.commit()
                cursor.close()
                conn.close()
                return render_template('error.html', error="Page does not exist")


            for eventinfo in eventdata:
                #in order it is:
                #Name, Description, Email, Phone, Loacation, startdate, endDate, eventId
                event_data = [
                    eventinfo[1], eventinfo[3], eventinfo[4], eventinfo[5], eventinfo[6], eventinfo[7], eventinfo[8], _event_id
                ]

            edate_start = event_data.pop(5)
            new_edate_start = datetime.strftime(edate_start, '%m/%d/%Y %I:%M %p')
            event_data.append(new_edate_start)

            edate_end = event_data.pop(5)
            new_edate_end = datetime.strftime(edate_end, '%m/%d/%Y %I:%M %p')
            event_data.append(new_edate_end)

            cursor.close()
            conn.close()

            return render_template('eventapproval.html', eventinfo = event_data)
        else:
            return render_template('error.html', error="You must be logged in to access this page.")

    except Exception as err:
        return json.dumps({'Exception error':str(err)})

@app.route('/approveevent', methods=['POST'])
def approve_event():
    try:
        _event = request.form['eventId']

        conn = mysql.connect()
        cursor = conn.cursor()
        print("hi")
        cursor.execute("UPDATE events SET event_approval = 1 WHERE event_id = "+_event+";")
        print("hello")
        conn.commit()

        data = cursor.fetchall()

        if len(data) == 0:
            flash("Event Approved!", 'alert-success')
        else:
            flash("Could not approve event", 'alert-warning')
        return redirect("/userhome")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/userhome')
def userhome():
    try:
        if session.get('user'):

            _viewby = session.get('event-view-type')
            
            _sortby = session.get('event-sort-type')
            _userUniversity = session.get('user-university')
        
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.callproc('sp_get_events_by_type_sort', (_viewby, _sortby, _userUniversity))
            events = cursor.fetchall()

            events_list = []
            for event in events:
                if(event[10]):
                    event_item = [
                        event[1], event[3], event[0]
                    ]
                    events_list.append(event_item)

            cursor.close()
            conn.close()

            return render_template('userhome.html', events=events_list)
        else:
            return render_template('error.html', error="You must be logged in to access this page.")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})


@app.route('/change_type', methods=['POST'])
def change_type_sort():
    _type = request.form['eventType']
    session['event-view-type'] = _type
    return redirect('/userhome')

@app.route('/event/<eventid>')
def show_event_profile(eventid):
    # show the event profile for that event
    try:    
        if session.get('user'):
            _event_id = int(eventid)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.callproc('sp_get_event', (eventid, ))
            eventdata = cursor.fetchall()

            if len(eventdata) == 0:
                conn.commit()
                cursor.close()
                conn.close()
                return render_template('error.html', error="Page does not exist")


            for eventinfo in eventdata:
                #in order it is:
                #Name, Description, Email, Phone, Loacation, startdate, endDate, eventId, registrationlink
                event_data = [
                    eventinfo[1], eventinfo[3], eventinfo[4], eventinfo[5], eventinfo[6], eventinfo[7], eventinfo[8], _event_id,eventinfo[11]
                ]

            edate_start = event_data.pop(5)
            new_edate_start = datetime.strftime(edate_start, '%m/%d/%Y %I:%M %p')
            event_data.append(new_edate_start)

            edate_end = event_data.pop(5)
            new_edate_end = datetime.strftime(edate_end, '%m/%d/%Y %I:%M %p')
            event_data.append(new_edate_end)

            cursor.close()
            conn.close()

            conn = mysql.connect()
            cursor = conn.cursor()            

            cursor.callproc('sp_get_comments', (_event_id, ))
            data = cursor.fetchall()

            loaded_comments=[]
            for comment in data:
                if comment[4]<3:
                    comment_data = [
                        comment[1], comment[2], comment[3], comment[0], comment[4], comment[5]
                        # name    , descriptio, event_id  , comment_id,  flag     , likes
                    ]
                    loaded_comments.append(comment_data)

            cursor.close()
            conn.close()

            stdate=str(event_data[7])
            if stdate[17:19]=="AM":
                stdate=stdate[6:10]+stdate[0:2]+stdate[3:5]+"T"+stdate[11:13]+stdate[14:16]+"00"
            else:
                stdate=stdate[6:10]+stdate[0:2]+stdate[3:5]+"T"+str(int(stdate[11:13])+12)+stdate[14:16]+"00"
            
            endate=str(event_data[8])
            if endate[17:19]=="AM":
                endate=endate[6:10]+endate[0:2]+endate[3:5]+"T"+endate[11:13]+endate[14:16]+"00"
            else:
                endate=endate[6:10]+endate[0:2]+endate[3:5]+"T"+str(int(endate[11:13])+12)+endate[14:16]+"00"

            #print(stdate)

            if session.get('user_role') == 'super_admin':
                return render_template('event_super_admin.html', eventinfo = event_data, comments = loaded_comments,start=stdate,end=endate)
            else:
                return render_template('event.html', eventinfo = event_data, comments = loaded_comments,start=stdate,end=endate)
        else:
            return render_template('error.html', error="You must be logged in to access this page.")

    except Exception as err:
        return json.dumps({'Exception error':str(err)})

@app.route('/createcomment')
def create_comment():
    return render_template('commentmaker.html')

@app.route('/flag', methods=['POST'])
def add_flag():
    try:
        _comment_id = request.form['comment_id']
        _event = request.form['eventId']

        conn = mysql.connect()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE comments SET comment_flag = comment_flag + 1 WHERE comment_id = "+_comment_id+";")
        conn.commit()

        data = cursor.fetchall()

        if len(data) == 0:
            flash("Comment Flagged", 'alert-success')
        else:
            flash("Could not flag comment")
        return redirect("/event/"+_event)
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/like', methods=['POST'])
def add_likes():
    try:
        _comment_id = request.form['comment_id']
        _event = request.form['eventId']

        conn = mysql.connect()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE comments SET comment_likes = comment_likes + 1 WHERE comment_id = "+_comment_id+";")
        conn.commit()

        data = cursor.fetchall()

        if len(data) == 0:
            flash("Comment Liked", 'alert-success')
        else:
            flash("Could not like comment")
        return redirect("/event/"+_event)
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/validate_comment', methods=['POST'])
def validate_comment():
    try:
        _body = request.form['commentBody']
        _event = request.form['eventId']
        _user = session.get('user-first-name')

        #let's call MySQL
        conn = mysql.connect()
        cursor = conn.cursor()
        if(len(_body)==0):
            flash("Comment empty!",'alert-warning')
            return redirect("/event/"+_event)
        cursor.callproc('sp_create_comment', (_user, _body, _event))
        data = cursor.fetchall()

        if len(data) == 0:
            conn.commit()
            flash("Comment Created!", 'alert-success')
            return redirect(url_for('show_event_profile', eventid=_event))
        else:
            flash("Could not create comment")
        return redirect('/userhome')

    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/validate_signin', methods=['POST'])
def validate_signin():
    try:
        _email = request.form['inputEmail']
        _password = request.form['inputPassword']

        #let's call MySQL
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.callproc('sp_validate_signin', (_email,))
        data = cursor.fetchall()

        if len(data) > 0:
            #make sure to update this line if schema changes
            #currently password is located as the 3rd column in users table
            if check_password_hash(str(data[0][2]), _password):
                session['user'] = data[0][0]
                session['event-view-type'] = 'public'
                session['event-sort-type'] = 'event_date'
                session['user_role'] = data[0][3]
                session['user-first-name'] = data[0][4]
                session['user-last-name'] = data[0][5]
                session['message-sort'] = 'message_id'
                session['user-university'] = data[0][6]
                session['user-email'] = data[0][1]
                return redirect('/userhome')
            else:
                flash("Invalid Password")
                return render_template('signin.html')
        flash("That email is not registered")
        return render_template('signin.html')

    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/validate_signup', methods=['POST'])
def validate_signup():
    try:
        _firstname = request.form['inputFirstName']
        _lastname = request.form['inputLastName']
        _email = request.form['inputEmail']
        _password = request.form['inputPassword']
        _universityid = request.form['universitySelector']

        #let's call MySQL
        conn = mysql.connect()
        cursor = conn.cursor()
        _hashed_password = generate_password_hash(_password)
        cursor.callproc('sp_create_user', (_firstname, _lastname, _email, _hashed_password, _universityid))
        data = cursor.fetchall()

        if len(data) == 0:
            conn.commit()
            flash("Account Created!", 'alert-success')
            return render_template('signin.html')
        else:
            flash("That Email is already registered")
        return render_template('signup.html')

    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/validate_university', methods=['POST'])
def validate_university():
    try:
        _universityname = request.form['universityName']
        _universitylocation = request.form['universityLocation']
        _universitydomain = request.form['universityDomain']

        #let's call MySQL
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.callproc('sp_create_university', (_universityname, _universitylocation, _universitydomain))
        data = cursor.fetchall()

        if len(data) == 0:
            conn.commit()
            flash("University Created!", 'alert-success')
            return render_template('userhome.html')
        else:
            flash("That University is already registered")
        return render_template('universitymaker.html')

    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/createevent')
def create_event():
    if session.get('user_role') =='admin':
        return render_template('eventmaker.html',show=0)
    else:
        if session.get('user_role') == 'super_admin':
            return render_template('eventmaker_super_admin.html',show=1)
        else:
            return render_template('error.html', error="You must be logged in to access this page.")

@app.route('/delete_event', methods=['POST'])
def delete_event():
    try:
        if session.get('user_role') == 'super_admin':
            _event = request.form['eventId']
            conn = mysql.connect()
            cursor = conn.cursor()
        
            cursor.execute("DELETE FROM events WHERE event_id="+_event+";")
            conn.commit()
            data = cursor.fetchall()

            if len(data) == 0:
                flash("Event deleted successfully", 'alert-success')
            else:
                flash("Could not delete event", 'alert-warning')
            return redirect("/userhome")
        else:
            return render_template('error.html', error="You do not have the rights to delete event.")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/modify_event', methods=['POST'])
def modify_event():
    try:
        if session.get('user_role') == 'super_admin':
            _event = request.form['eventId']
            conn = mysql.connect()
            cursor = conn.cursor()

            #cursor.callproc('sp_get_event', (_event))
            cursor.execute("select * from events where event_id = "+_event+";")
            
            conn.commit()
            data = cursor.fetchall()

            for event in data:
                event_details = [event[0], event[1],event[2],event[3],event[4],event[5],event[6],event[7],event[8],event[11]]

            if len(data) == 0:
                flash("Could not modify event", 'alert-warning')
            else:
                return render_template('/eventmodifier.html',event_deets=event_details)
            return redirect("/userhome")
        else:
            return render_template('error.html', error="You do not have the rights to modify event.")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/event_modification',methods=['POST'])
def event_modification():
    try:
        if session.get('user_role') == 'super_admin':
            _event = request.form['eventId']
            _eventName = request.form['eventName']
            _eventType = request.form['eventType']
            _eventDescription = request.form['eventDescription']
            _eventEmail = request.form['eventEmail']
            _eventPhone = request.form['eventPhone']
            _eventLocation = request.form['eventLocation']
            _eventStart = request.form['eventStart']
            _eventEnd = request.form['eventEnd']
            _eventRegistration=request.form['eventRegistration']


            date_object = datetime.strptime(_eventStart, '%m/%d/%Y %I:%M %p')
            date_object2 = datetime.strptime(_eventEnd, '%m/%d/%Y %I:%M %p')

            conn = mysql.connect()
            cursor = conn.cursor()
            
            cursor.execute("UPDATE events SET event_name='"+_eventName+"',event_type='"+_eventType+"',event_description='"+_eventDescription+"',event_email='"+_eventEmail+"',event_phone="+_eventPhone+",event_location='"+_eventLocation+"',event_date_start='"+str(date_object)+"',event_date_end='"+str(date_object2)+"',event_link='"+_eventRegistration+"' WHERE event_id="+_event+";")

            conn.commit()
            data = cursor.fetchall()

            if len(data) == 0:
                flash("Event modified successfully!", 'alert-success')
            else:
                flash("Event could not be modified",'alert-warning')
            return redirect("/event/"+_event)
        else:
            return render_template('error.html', error="You do not have the rights to modify event.")
    except Exception as err:
        return json.dumps({'Exception error':str(err)})
    finally:
        cursor.close()
        conn.close()

@app.route('/createuniversity')
def create_university():
    if session.get('user_role') == 'super_admin':
        return render_template('universitymaker.html')
    else:
        return render_template('error.html', error="You do not have the rights to access this page.")

@app.route('/validate_event', methods=['POST'])
def validate_event():
    try:
        _eventName = request.form['eventName']
        _eventType = request.form['eventType']
        _eventDescription = request.form['eventDescription']
        _eventEmail = request.form['eventEmail']
        _eventPhone = request.form['eventPhone']
        _eventLocation = request.form['eventLocation']
        _eventStart = request.form['eventStart']
        _eventEnd = request.form['eventEnd']
        _eventuniversity = session.get('user-university')
        _eventApproval=request.form['approveEvent']
        _eventRegistration=request.form['eventRegistration']

        date_object = datetime.strptime(_eventStart, '%m/%d/%Y %I:%M %p')
        date_object2 = datetime.strptime(_eventEnd, '%m/%d/%Y %I:%M %p')

        #let's call MySQL
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.callproc('sp_create_event', (_eventName, _eventType, _eventDescription, _eventEmail, _eventPhone, _eventLocation, date_object, date_object2, _eventuniversity,_eventApproval,_eventRegistration))
        conn.commit()
        cursor.close()
        conn.close()
        if(_eventApproval is 1):
            flash("The event has been created.", 'alert-success')
        else:
            flash("Event request sent successfully!",'alert-success')
        return render_template('userhome.html')
    except Exception as err:
        return json.dumps({'Exception error':str(err)})

@app.route('/signout')
def signout():
    session.pop('user', None)
    return redirect('/')

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error="We're sorry. We could not find the requested page.")

if __name__ == '__main__':
    app.run(debug = True)
