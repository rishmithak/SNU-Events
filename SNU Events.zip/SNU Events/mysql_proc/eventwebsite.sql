-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2021 at 05:57 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventwebsite`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_comment` (IN `p_user` VARCHAR(255), IN `p_body` VARCHAR(255), IN `p_event` INT(8))  BEGIN
        insert into comments
        (
            comment_poster,
            comment_body,
            comment_event
        )
        values
        (
            p_user,
            p_body,
            p_event
        );
     
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event` (IN `p_eventName` VARCHAR(255), IN `p_eventType` VARCHAR(45), IN `p_eventDescription` VARCHAR(255), IN `p_eventEmail` VARCHAR(255), IN `p_eventPhone` VARCHAR(255), IN `p_eventLocation` VARCHAR(255), IN `p_eventDateStart` DATETIME, IN `p_eventDateEnd` DATETIME, IN `p_eventuniversity` VARCHAR(255), IN `p_eventapproval` INT, IN `p_eventRegistration` VARCHAR(255))  BEGIN     
        insert into events
        (
            event_name,
            event_type,
            event_description,
            event_email,
            event_phone,
            event_location,
            event_date_start,
            event_date_end,
            event_university,
            event_approval,
            event_link
        )
        values
        (
            p_eventName,
            p_eventType,
            p_eventDescription,
            p_eventEmail,
            p_eventPhone,
            p_eventLocation,
            p_eventDateStart,
            p_eventDateEnd,
            p_eventuniversity,
            p_eventapproval,
            p_eventRegistration
        );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_university` (IN `p_universityname` VARCHAR(255), IN `p_universitylocation` VARCHAR(255), IN `p_universitydomain` VARCHAR(45))  BEGIN
    if ( select exists (select 1 from universities 
        where university_name = p_universityname or
        university_domain = p_universitydomain
        ) ) THEN
     
        select 'University Exists !!';
     
    ELSE
     
        insert into universities
        (
            university_name,
            university_domain,
            university_location
        )
        values
        (
            p_universityname,
            p_universitydomain,
            p_universitylocation
        );
     
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_user` (IN `p_firstname` VARCHAR(45), IN `p_lastname` VARCHAR(45), IN `p_email` VARCHAR(255), IN `p_password` VARCHAR(255), IN `p_university_id` INT(8))  BEGIN
    if ( select exists (select 1 from users where user_email = p_email) ) THEN
     
        select 'Username Exists !!';
     
    ELSE
     
        insert into users
        (
            user_firstname,
            user_lastname,
            user_email,
            user_password,
            user_university
        )
        values
        (
            p_firstname,
            p_lastname,
            p_email,
            p_password,
            p_university_id
        );
     
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_comments` (IN `p_event` INT(8))  BEGIN
    select * from comments where comment_event = p_event;
     
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_event` (IN `p_event_id` INT(8))  BEGIN
    select * from events where event_id = p_event_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_events_by_type_sort` (IN `p_event_type` VARCHAR(45), IN `p_event_sort` VARCHAR(45), IN `p_university_id` INT(8))  BEGIN
    IF (p_event_type = 'private') THEN
        select * from events where
            event_university = p_university_id
            AND event_type = 'private'
            order by 
            p_event_sort;
    ELSE 
        select * from events 
            where event_type = p_event_type 
            order by 
            p_event_sort;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_universities` ()  BEGIN
    select * from universities;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_increment_flag` (IN `p_comment_id` INT(8))  BEGIN
    UPDATE comments SET comment_flag = comment_flag + 1 WHERE comment_id = p_comment_id;
     
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validate_signin` (IN `p_email` VARCHAR(255))  BEGIN
    select * from users where user_email = p_email;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(8) NOT NULL,
  `comment_poster` varchar(255) NOT NULL,
  `comment_body` varchar(255) NOT NULL,
  `comment_event` int(8) NOT NULL,
  `comment_flag` int(1) NOT NULL DEFAULT 0,
  `comment_likes` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_poster`, `comment_body`, `comment_event`, `comment_flag`, `comment_likes`) VALUES
(1, 'Prasanna', 'Interesting topic', 1, 0, 4),
(2, 'Monika', 'Excited for the event.', 2, 0, 0),
(3, 'Snayga', 'Eager to learn', 1, 0, 6),
(4, 'Sravya', 'Looking forward to it!!', 3, 0, 0),
(5, 'Akanksha', 'Will be there', 2, 0, 1),
(6, 'Rishmitha', 'Cannot wait', 3, 0, 0),
(7, 'Pardhav', 'Health is wealth', 3, 0, 0),
(18, 'Monika', 'Feel the breeze', 23, 0, 0),
(19, 'Monika', 'I love this dance form', 24, 0, 0),
(20, 'Prasanna', 'Sustainability and arts. Such a novel idea!', 26, 0, 1),
(21, 'Prasanna', 'Arts are therapeutic', 25, 0, 0),
(22, 'Prasanna', 'Such a cultural phenomenon', 24, 0, 0),
(23, 'Prasanna', 'inclusion++++', 4, 0, 2),
(25, 'Deepika', 'Hiii', 1, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(8) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_type` varchar(45) NOT NULL,
  `event_description` varchar(255) NOT NULL,
  `event_email` varchar(255) NOT NULL,
  `event_phone` varchar(255) NOT NULL,
  `event_location` varchar(255) NOT NULL,
  `event_date_start` datetime NOT NULL,
  `event_date_end` datetime NOT NULL,
  `event_university` int(8) DEFAULT NULL,
  `event_approval` int(11) DEFAULT 1,
  `event_link` varchar(255) DEFAULT 'Registration not required'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_type`, `event_description`, `event_email`, `event_phone`, `event_location`, `event_date_start`, `event_date_end`, `event_university`, `event_approval`, `event_link`) VALUES
(1, 'Water Policy', 'private', 'The 2022 IWA International conference for water safety planning (IWA – WSP conference) will bring together leading international experts from academia, industry, government, policymakers/authorities and other organizations to actively exchange and share.', 'iwa.snu@snu.edu.in', '9988778787', 'A017', '2021-11-28 15:00:00', '2021-11-28 15:30:00', 1, 1, 'https://forms.gle/VXfAkwDWYnJpDDH97'),
(2, 'MazeExplorer', 'public', 'Take a chill pill or go to the hallow shack. But whatever you do, by the end of it, do not forget to say mischief managed cause you don\'t want your secrets spilling especially all over the darker web. It\'s not spooky or is it..', 'adventure@snu.edu.in', '9879879879', 'Online', '2021-11-28 14:30:00', '2021-11-28 15:00:00', 1, 1, 'https://forms.gle/ocC5bWwTkEU6MeWc8'),
(3, 'Healthy Life', 'private', 'Elena A Christofides, MD, FACE, will identify the impact of COVID-19 on people with diabetes mellitus (DM); discuss the effect of DM on COVID-19 infection; review evidence of best practices for clinicians caring for people with DM & nutrition', 'gu@snu.edu.in', '7987987987', 'D block Ground Floor', '2021-11-28 14:30:00', '2021-11-28 15:00:00', 1, 1, 'Registration not required'),
(4, 'All Q', 'private', 'Learn the nuances of the queer culture through the ages. Discuss your favorite pop queer icons and much more.', 'lgbt@snu.edu.in', '9898987878', 'C207', '2021-11-29 14:00:00', '2021-11-29 16:30:00', 1, 1, 'Registration not required'),
(23, 'BREEZE Launch Event ', 'public', 'Breeze is finally back, more vibrant than ever before and with all the memories and bonds we love it for. Get ready to experience the best times of your life, as we bring you the most exciting and electrifying 3 days and nights of this academic year. ', 'breeze@snu.edu.in', '9797898989', 'B315', '2021-11-28 14:30:00', '2021-11-28 15:00:00', 1, 1, 'Registration not required'),
(24, 'Evening of Mohiniyattam', 'public', 'Ms. Shivaji is an Indian Classical dancer, specializing in Mohiniyattam. She has co-authored two books, namely \'Mohiniyattam\' and \'The Art of Mohiniyattam\' and is the founder of the Centre for Mohiniyattam. In addition to the Padma Shri, she has also rece', 'spicmacay@snu.edu.in', '7878989898', 'C007', '2021-12-04 16:00:00', '2021-12-04 18:00:00', 1, 1, 'Registration not required'),
(25, 'Fluid Art Jam', 'public', 'With a large number of returning students, the campus is lively again. Now it\'s time to return to an offline event where we can all unwind and take a breather (we sure need one with the end semester exams approaching). Kalakriti has in store for you an of', 'kalakriti@snu.edu.in', '7986867878', 'A112', '2021-12-22 19:30:00', '2021-12-22 21:30:00', 1, 1, 'Registration not required'),
(26, 'Art and Environmental Struggle', 'public', 'Art and Environmental Struggle brings together the work of twenty artists responding to environmental challenges occurring in their countries and communities. Presented in conjunction with an international conference at SNU, this exhibition features artis', 'mfa@snu.edu.in', '7986864545', 'F block 2nd floor', '2021-12-23 21:00:00', '2021-12-25 21:00:00', 1, 1, 'Registration not required'),
(27, 'Bipartisan really?', 'private', 'Join two former Members of Congress from Long Island for a behind the scenes discussion on what has led to the current climate of crisis on Capitol Hill and what can be done to restore civility and consensus.', 'snusc@snu.edu.in', '9898787876', 'virtual', '2021-11-28 21:30:00', '2021-11-28 22:00:00', 1, 1, 'http://surl.li/aupsp'),
(28, 'Emerging Markets Still Make Sense', 'public', 'How can one compare the growth of countries in different regions with distinct cultures, governments, and geopolitical situations? Members of the research team', 'eco@snu.edu.in', '8989898787', 'virtual', '2021-11-30 16:30:00', '2021-11-30 19:00:00', 1, 1, 'http://surl.li/aupro');

-- --------------------------------------------------------

--
-- Table structure for table `universities`
--

CREATE TABLE `universities` (
  `university_id` int(8) NOT NULL,
  `university_name` varchar(255) NOT NULL,
  `university_domain` varchar(45) NOT NULL,
  `university_location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `universities`
--

INSERT INTO `universities` (`university_id`, `university_name`, `university_domain`, `university_location`) VALUES
(7, 'Amity University', 'amity', 'Greater Noida'),
(2, 'Ashoka University', 'au', 'Sonipat'),
(6, 'Bennett University', 'bu', 'Gautam Buddha Nagar'),
(1, 'Shiv Nadar University', 'snu', 'Delhi NCR');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(8) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` varchar(20) NOT NULL DEFAULT 'student',
  `user_firstname` varchar(45) NOT NULL,
  `user_lastname` varchar(45) NOT NULL,
  `user_university` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_password`, `user_role`, `user_firstname`, `user_lastname`, `user_university`) VALUES
(1, 'sc330@snu.edu.in', 'pbkdf2:sha256:260000$cSfGm4WMxoOcTLBi$0fd8caf8d426284ddc0e5e8c94105db07ffd9139fdd453122ca4d02683664ded', 'super_admin', 'Snayga', 'CR', 1),
(2, 'sk734@snu.edu.in', 'pbkdf2:sha256:260000$oyN5ZzZboxvix8Zq$e1b451f7f54fc4b14f59d3cbfac22ea9036aa49543f4ace93c70ebe0c6860f18', 'admin', 'Rishmitha', 'K', 1),
(3, 'rd546@snu.edu.in', 'pbkdf2:sha256:260000$5MN2QX3XqU81aGom$77d699bdd4afc0040c57b19b3aba56bdbf63d21e726af07853f86e5c47e7c0e7', 'admin', 'Deepika', 'R', 1),
(4, 'jp347@snu.edu.in', 'pbkdf2:sha256:260000$5MN2QX3XqU81aGom$77d699bdd4afc0040c57b19b3aba56bdbf63d21e726af07853f86e5c47e7c0e7', 'student', 'Pardhav', 'J', 1),
(5, 'nl547@snu.edu.in', 'pbkdf2:sha256:260000$dwpvFQVgenXY0fjL$c90ada550291e873dfdb2ead32fb64286197c7f18b309d3e72bcf581671821aa', 'student', 'Sravya', 'N', 1),
(11, 'ks937@snu.edu.in', 'pbkdf2:sha256:260000$G58fZ6hoqrk1chtk$479e62ec15fbab7fc7b04cb91ae0da0c4107175640c7c8979d9b8af25b5a5862', 'student', 'Sindhu', 'K', 1),
(12, 'sk168@snu.edu.in', 'pbkdf2:sha256:260000$Vx7Ao5imrJvcEmLc$4b5edb9c973aa0eb3555c8a1b4b2d1c972872a4ca398119b38e7d7a8f1c3563e', 'student', 'Sahithi', 'K', 1),
(13, 'sg531@snu.edu.in', 'pbkdf2:sha256:260000$sdAfj9IAa3WeuCKC$4de2ba5ee3c70f52d8dfb4be584fd32ce28b1697112b516ccdad1164f2dbb537', 'student', 'Akanksha', 'G', 1),
(14, 'rc826@snu.edu.in', 'pbkdf2:sha256:260000$7YCTRsvtVD2QJpf0$7b362418441186e751ff536bc7e503a96e1049b8ca9043068b5d18652d91f423', 'student', 'Monika', 'R', 1),
(15, 'sk914@snu.edu.in', 'pbkdf2:sha256:260000$vYG2PdD8icSrWSQI$4fae3e18e5b601716b3872b8772e164c9512e25d1e1e018a11dc3c78e1654cfa', 'student', 'Prasanna', 'K', 1),
(16, 'ak564@snu.edu.in', 'pbkdf2:sha256:260000$6vlDO2a3gr2S693i$a8b032cd37242132ea14b8ccdf0e162e2c239268ec9aae2e6b503eb814468503', 'student', 'Anamika', 'K', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `event_id` (`event_id`,`event_name`);

--
-- Indexes for table `universities`
--
ALTER TABLE `universities`
  ADD PRIMARY KEY (`university_id`),
  ADD UNIQUE KEY `university_name` (`university_name`,`university_domain`,`university_location`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `universities`
--
ALTER TABLE `universities`
  MODIFY `university_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
